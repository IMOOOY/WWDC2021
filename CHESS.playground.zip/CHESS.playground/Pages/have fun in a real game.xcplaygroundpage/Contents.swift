/*:
 # Have fun in a real game!

 **I assume you now know the basic rule of chinese chess.**

 (If you are not, you can return to the previous page at any time.)
 */
//: [Return to the previous page](@previous)
/*:
 **Have a try in a real game.**

 Don't be afraid, during the game, you will be given tips on how to move the pieces. I will also forbid you to make any illegal move.

 ###### Two levels of AI robots is provided to chess with you. Try the entry level opponent first.

 *If you're ready, you are welcomed to challeng the advanced level!*
 */




import PlaygroundSupport
PlaygroundPage.current.liveView = gameMyViewController()
