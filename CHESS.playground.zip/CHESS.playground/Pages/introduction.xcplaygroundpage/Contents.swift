/*:
 # HI! Have you ever heard Chineese Chess?



 ##### It's **Yang Jingjie**, a computer science student from China.

 In this playground, I am going to show you a special **CHESS** game originated in China.

 ------



 Have you watched this year's hit series ***Queen's Gambit***. It has got me very interested in chess.

 And at the same time, as a Chinese, I also developed the idea of presenting **Chinese chess** to the world, in the hope that more international friends would have the opportunity to experience and understand the charm of chess.

 ###### That's where I got my inspiration of this playground.



 In the first two parts, I will take you through Chinese chess and you will learn some of basic rules of chess.



 Afterwards, I designed an **AI** you can play a real game with. It may not be as good as Alpha GO, but still, I hope it can bring you an enjoyable experience



 > Now, **run the code** and let me introduce you to Chinese Chess
 */


//#-hidden-code
import PlaygroundSupport
PlaygroundPage.current.liveView = introViewController()
//#-end-hidden-code
//: [Learn rules in next page](@next)
