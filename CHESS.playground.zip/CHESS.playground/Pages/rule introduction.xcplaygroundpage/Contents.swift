//: [Return to the previous page](@previous)
/*:
 
 # Learn the rules of Chinese Chess!

 In this page, I will show you the basic rules of Chinese Chess. And hopefully, you will be able to actually play a game!

------

 */

import PlaygroundSupport
PlaygroundPage.current.liveView = ruleMyViewController()

//: [Have a real game in next page](@next)
