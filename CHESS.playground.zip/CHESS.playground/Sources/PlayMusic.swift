import Foundation
import AVFoundation

var player: AVAudioPlayer?
//
//guard let url =  Bundle.main.url(forResource: "bgm", withExtension: "mp3" ) else {
//    print("not fund")
//    return
//}


public func playMusic(musicUrl: URL) {
    do {
        try AVAudioSession.sharedInstance().setMode(.default)
        try AVAudioSession.sharedInstance().setActive(true, options: .notifyOthersOnDeactivation)
        
        player = try AVAudioPlayer(contentsOf: musicUrl)
        player?.play()
    } catch {
        print("something wrong !")
    }
}
