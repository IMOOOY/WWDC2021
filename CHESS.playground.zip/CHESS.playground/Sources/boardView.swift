import Foundation
import UIKit
import SwiftUI

public class boardView: UIView {

    var chessesB:[chess] = [pao(),che(),ma(),xiang(),shi(),jiang(),pao(),che(),ma(),xiang(),shi(),zu(),zu(),zu(),zu(),zu()]
    var chessesR:[chess] = [pao(),che(),ma(),xiang(),shi(),jiang(),pao(),che(),ma(),xiang(),shi(),zu(),zu(),zu(),zu(),zu()]
    
    
    let lineWidth = 1 / UIScreen.main.scale
    let lineAdjustOffset = 1 / UIScreen.main.scale / 2
    var width:CGFloat = 80
    var height:CGFloat = 90
//    var padding:CGFloat = 50
    var colWidth:CGFloat = 10
    var rowHeight:CGFloat = 10
    
    
    var chuhe = UIImageView(image: UIImage(named: "楚河.png"))
//    var chuhe = UILabel()
//    var hanjie = UILabel()
    var hanjie = UIImageView(image: UIImage(named: "hanjie.png"))
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        let boardBg = UIImage(named: "bg2.bmp")        
        self.backgroundColor = UIColor.init(patternImage: boardBg!)
        
        
        
        
        chuhe.frame = CGRect(origin: getCordinate(x: 2, y: 5), size: CGSize(width: colWidth*2, height: rowHeight))
//        chuhe.backgroundColor = .clear
//        chuhe.textAlignment = .center
//        chuhe.text = "楚河"
//        chuhe.textColor = .black
//        chuhe.font = UIFont.systemFont(ofSize: 30)
//        chuhe.adjustsFontSizeToFitWidth = true
        
        hanjie.frame = CGRect(origin: getCordinate(x: 6, y: 5), size: CGSize(width: colWidth*2, height: rowHeight))
//        hanjie.backgroundColor = .clear
//        hanjie.textAlignment = .center
//        hanjie.text = "汉界"
//        hanjie.textColor = .black
//        hanjie.font = UIFont.systemFont(ofSize: 30)
//        hanjie.adjustsFontSizeToFitWidth = true
        
        self.addSubview(chuhe)
        self.addSubview(hanjie)
        
        
        
        
        
        for index in 0...15
        {
            self.addSubview(chessesR[index])
            self.addSubview(chessesB[index])

        }
    }
    
    
    public func setSizeAndPosition(width: CGFloat,x:CGFloat,y:CGFloat, screenWidth:CGFloat)
    {
        self.width = width
        self.height = width/10.0*11.0
        colWidth = width/10
        rowHeight = height/11
        self.frame = CGRect(x: x, y: y, width: width, height: height)
        
        
        chuhe.frame = CGRect(origin: getCordinate(x: 2, y: 5), size: CGSize(width: colWidth*2, height: rowHeight))
        hanjie.frame = CGRect(origin: getCordinate(x: 6, y: 5), size: CGSize(width: colWidth*2, height: rowHeight))
        
//          chesses[0].setSize(size: colWidth-20)
//          chesses[0].setPosition(p: getCordinate(x: 1, y: 1))
        
        for index in 0...10
        {

            chessesR[index].set(sizeOfTheChess:colWidth*0.9,sideOfTheChess:0,no:index<6 ? 1 : 2)
            chessesR[index].setPosition(p: getCordinate(x: Int(chessesR[index].initPosition.x), y: Int(chessesR[index].initPosition.y)))
            chessesB[index].set(sizeOfTheChess:colWidth*0.9,sideOfTheChess:1,no:index<6 ? 1 : 2)
            chessesB[index].setPosition(p: getCordinate(x: Int(chessesB[index].initPosition.x), y: Int(chessesB[index].initPosition.y)))
        }
        for index in 11...15
        {
            chessesR[index].set(sizeOfTheChess:colWidth*0.9,sideOfTheChess:0,no:index-10)
            chessesR[index].setPosition(p: getCordinate(x: Int(chessesR[index].initPosition.x), y: Int(chessesR[index].initPosition.y)))
            chessesB[index].set(sizeOfTheChess:colWidth*0.9,sideOfTheChess:1,no:index-10)
            chessesB[index].setPosition(p: getCordinate(x: Int(chessesB[index].initPosition.x), y: Int(chessesB[index].initPosition.y)))

        }
        
//        chessesB[1].set(sizeOfTheChess:colWidth*0.9,sideOfTheChess:1,no:1)
//        chessesB[1].setPosition(p: getCordinate(x:chessesB[1].initPosition.x, y: chessesB[1].initPosition.y))
//        chessesR[1].set(sizeOfTheChess:colWidth*0.9,sideOfTheChess:0,no:1)
//        chessesR[1].setPosition(p: getCordinate(x:chessesR[1].initPosition.x, y: chessesR[1].initPosition.y))

        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public override func draw(_ rect: CGRect) {
        super.draw(rect)


        guard let context = UIGraphicsGetCurrentContext() else
        {
            return
        }

        let drawingRect = self.bounds.insetBy(dx: lineAdjustOffset, dy: lineAdjustOffset)

        //创建并设置路径
       let path = CGMutablePath()
       //外边框
//         path.addRect(drawingRect)
        
        
        for x in 1...9
        {
            path.move(to: getCordinate(x: x, y: 1))
            path.addLine(to: getCordinate(x: x, y: 5))
            
            path.move(to: getCordinate(x: x, y: 6))
            path.addLine(to: getCordinate(x: x, y: 10))

        }
        for y in 1...10
        {
            path.move(to: getCordinate(x: 1, y: y))
            path.addLine(to: getCordinate(x: 9, y: y))
        }
        
        path.move(to: getCordinate(x: 4, y: 1))
        path.addLine(to: getCordinate(x: 6, y: 3))
        
        path.move(to: getCordinate(x: 4, y: 3))
        path.addLine(to: getCordinate(x: 6, y: 1))
        
        path.move(to: getCordinate(x: 4, y: 8))
        path.addLine(to: getCordinate(x: 6, y: 10))
        
        path.move(to: getCordinate(x: 4, y: 10))
        path.addLine(to: getCordinate(x: 6, y: 8))
        
        
        
        
        
        

       //添加路径到图形上下文
       context.addPath(path)

       //设置笔触颜色
       context.setStrokeColor(UIColor.black.cgColor)
       //设置笔触宽度
       context.setLineWidth(lineWidth)

       //绘制路径
       context.strokePath()

    }
    public func getCordinate(x:Int, y:Int) -> CGPoint
    {
        var cordinate = CGPoint(x: 0, y: 0)
        cordinate.x = colWidth*CGFloat(x)
        cordinate.y = rowHeight*CGFloat(y)
        return cordinate
    }
    
}
