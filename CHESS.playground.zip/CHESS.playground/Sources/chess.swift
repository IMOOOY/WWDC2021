import Foundation
import UIKit

public class chess: UIView
{
    public var gifName = String()
    public var typeName = String()
    public var ruleWords:String = String()
    enum s
    {   case red
        case black
    }
    var side:s = .red
    public var initPosition = CGPoint(x: 1, y: 1)
    var width:CGFloat = 10
    var no:Int = 1
    
    var img = UIImage(named: "shi.GIF")

    public func move() ->CGPoint
    {
        let destination = CGPoint(x: initPosition.x, y: initPosition.y)
        return destination
    }
    public func set(sizeOfTheChess:CGFloat,sideOfTheChess:Int,no:Int)
    {
        if sideOfTheChess ==  0
        {
            self.side = .red
        }
        else
        {
//            print("side == 1")
            self.side = .black
//            print(self.side)
        }
        self.no = no
        self.width = sizeOfTheChess
        self.frame = CGRect(x: 0, y:0, width: width, height: width)
    }
    public func setImg(imgName:String)
    {
        img = UIImage(named: imgName)
//          self.backgroundColor = UIColor(patternImage: img!)
        self.layer.contents = img?.cgImage
        
    }
    public func setPosition(p:CGPoint)
    {
        let position = CGPoint(x: p.x-width/2, y: p.y-width/2)
        self.frame=CGRect(origin: position, size: self.frame.size)
    }
    public override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.frame = CGRect(x: 0, y:0, width: width, height: width)
//          self.backgroundColor = .red
//          self.backgroundColor = UIColor(patternImage: img!)
        self.layer.contents = img?.cgImage
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}


public class che:chess
{
    public override func move() -> CGPoint {
        var des = super.move()
        des.y = initPosition.y+1
        if side == .red
        {
            des.y = initPosition.y-1
        }

        return des
    }
    public override func set(sizeOfTheChess:CGFloat,sideOfTheChess:Int,no:Int)
    {
        super.set(sizeOfTheChess: sizeOfTheChess, sideOfTheChess: sideOfTheChess, no: no)
        if side == .red
        {
//            print("red set")
            setImg(imgName: "rche.GIF")
            if no == 1
            {
                self.initPosition.x = 1
                self.initPosition.y = 10
            }
            else
            {
                self.initPosition.x = 9
                self.initPosition.y = 10
            }
        }
        else
        {
            setImg(imgName: "che.GIF")
            if no == 1
            {
                self.initPosition.x = 1
                self.initPosition.y = 1
            }
            else
            {
                self.initPosition.x = 9
                self.initPosition.y = 1
            }
        }
    }
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        gifName = "che.gif"
        setImg(imgName: "gif/che.GIF")
        typeName = "Rook (Car)"
        ruleWords = "The Rooks (Cars) move one or more spaces horizontally or vertically provided that all positions between the original and final positions are empty."
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
public class ma:chess
{
    public override func move() -> CGPoint {
        var des = super.move()
        
        des.x = initPosition.x+1
        des.y = initPosition.y + 2
        if no == 2
        {
            des.x = initPosition.x-1
        }
        if side == .red
        {
            des.x = initPosition.x-1
            des.y = initPosition.y - 2
            if no == 2
            {
                des.x = initPosition.x+1
            }
        }

        return des
    }
    public override func set(sizeOfTheChess:CGFloat,sideOfTheChess:Int,no:Int)
    {
        super.set(sizeOfTheChess: sizeOfTheChess, sideOfTheChess: sideOfTheChess, no: no)

        if side == .red
        {
            setImg(imgName: "rma.GIF")
            if no == 1
            {
                self.initPosition.x = 2
                self.initPosition.y = 10
            }
            else
            {
                self.initPosition.x = 8
                self.initPosition.y = 10
            }
        }
        else
        {
            if no == 1
            {
                self.initPosition.x = 2
                self.initPosition.y = 1
            }
            else
            {
                self.initPosition.x = 8
                self.initPosition.y = 1
            }
        }
  }
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        setImg(imgName: "ma.GIF")
        gifName = "gif/ma.gif"
        typeName = "Knight (Horse)"
        ruleWords = "The Knights (Horses) move two spaces horizontally and one space vertically (or respectively 2 spaces vertically and one space horizontally). If there is a piece next to the horse in the horizontal (vertical) direction, the horse is blocked and the move is not allowed"
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
public class xiang:chess
{
    public override func move() -> CGPoint {
        var des = super.move()
        
        des.x = initPosition.x + 2
        des.y = initPosition.y + 2

        if side == .red
        {
            des.x = initPosition.x - 2
            des.y = initPosition.y - 2
        }

        return des
    }
    public override func set(sizeOfTheChess:CGFloat,sideOfTheChess:Int,no:Int)
    {
        super.set(sizeOfTheChess: sizeOfTheChess, sideOfTheChess: sideOfTheChess, no: no)

        if side == .red
        {
            setImg(imgName: "rxiang.GIF")
            if no == 1
            {
                self.initPosition = CGPoint(x: 3, y: 10)
            }
            else
            {
                self.initPosition = CGPoint(x: 7, y: 10)
            }
        }
        else
        {
            if no == 1
            {
                self.initPosition = CGPoint(x: 3, y: 1)
            }
            else
            {
                self.initPosition = CGPoint(x: 7, y: 1)
            }
        }
    }
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        setImg(imgName: "xiang.GIF")
        gifName = "gif/xiang.gif"

        typeName = "The Minister (Elephant)"
        ruleWords = "The Ministers (Elephants) move two spaces at a time diagonally (i.e. 2 spaces left/right and 2 spaces up/down in a move). They must stay within their own side of the river. If there is a piece midway between the original and final intended position of a minister, the minister is blocked and the move is not allowed."
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
public class shi:chess
{
    public override func move() -> CGPoint {
        var des = super.move()


        if side == .red
        {
            des.x = initPosition.x+1
            des.y = initPosition.y - 1
            if no == 2
            {
                des.x = initPosition.x-1
                des.y = initPosition.y - 1
            }
        }
        else
        {
            des.x = initPosition.x+1
            des.y = initPosition.y + 1
            if no == 2
            {
                des.x = initPosition.x-1
                des.y = initPosition.y + 1
            }
        }
        
        return des
    }
    public override func set(sizeOfTheChess:CGFloat,sideOfTheChess:Int,no:Int)
    {
        super.set(sizeOfTheChess: sizeOfTheChess, sideOfTheChess: sideOfTheChess, no: no)

        if side == .red
        {
            setImg(imgName: "rshi.GIF")
            if no == 1
            {
                self.initPosition = CGPoint(x: 4, y: 10)
            }
            else
            {
                self.initPosition = CGPoint(x: 6, y: 10)
            }
        }
        else
        {
            if no == 1
            {
                self.initPosition = CGPoint(x: 4, y: 1)
            }
            else
            {
                self.initPosition = CGPoint(x: 6, y: 1)
            }
        }
    }
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        setImg(imgName: "shi.GIF")
        gifName = "gif/shi.gif"

        typeName = "Guard (Advisor)"
        ruleWords = "The Guards (Advisor) move only one space at a time diagonally. Similar to the King, the guards must stay within the palace."
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
public class jiang:chess
{
    public override func move() -> CGPoint {
        var des = super.move()
        des.y = initPosition.y + 1
        
        if side == .red
        {
            des.y = initPosition.y - 1
        }

        
        return des
    }
    public override func set(sizeOfTheChess:CGFloat,sideOfTheChess:Int,no:Int)
    {
        super.set(sizeOfTheChess: sizeOfTheChess, sideOfTheChess: sideOfTheChess, no: no)

        if side == .red
        {
            setImg(imgName: "rjiang.GIF")

                self.initPosition = CGPoint(x: 5, y: 10)
        }
        else
        {
                self.initPosition = CGPoint(x: 5, y: 1)

        }
    }
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        setImg(imgName: "jiang.GIF")
        gifName = "gif/jiang.gif"
        typeName = "King"
        ruleWords = "The King moves only one space at a time, either horizontally or vertically. Further more, the King must always stay within the palace, which is a square marked with an X"
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
public class pao:chess
{
    public override func move() -> CGPoint {
        var des = super.move()
        des.y = 10
        if side == .red
        {
            des.y = 1
        }
        
        return des
    }
    public override func set(sizeOfTheChess:CGFloat,sideOfTheChess:Int,no:Int)
    {
        super.set(sizeOfTheChess: sizeOfTheChess, sideOfTheChess: sideOfTheChess, no: no)

        if side == .red
        {
            setImg(imgName: "rpao.GIF")
            if no == 1
            {
                self.initPosition = CGPoint(x: 2, y: 8)
            }
            else
            {
                self.initPosition = CGPoint(x: 8, y: 8)
            }
        }
        else
        {
            if no == 1
            {
                self.initPosition = CGPoint(x: 2, y: 3)
            }
            else
            {
                self.initPosition = CGPoint(x: 8, y: 3)
            }
        }
        
    }
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        setImg(imgName: "pao.GIF")
        gifName = "gif/pao.gif"
        typeName = "Cannon"
        ruleWords = "The Cannons move one or more spaces horizontally or vertically like a Rook. However, in a capture move, there must be exactly one non-empty space in between the original and final position. In a non-capture move, all spaces in between must be empty."
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
public class zu:chess
{
    public override func move() -> CGPoint {
        var des = super.move()
        des.x = initPosition.x
        des.y = initPosition.y + 1
        if side == .red
        {
            des.y = initPosition.y - 1
        }
        return des
    }
    public override func set(sizeOfTheChess:CGFloat,sideOfTheChess:Int,no:Int)
    {
        super.set(sizeOfTheChess: sizeOfTheChess, sideOfTheChess: sideOfTheChess, no: no)

        if side == .red
        {
            setImg(imgName: "rzu.GIF")
            switch no {
            case 1:
                self.initPosition = CGPoint(x: 1, y: 7)
            case 2:
                self.initPosition = CGPoint(x: 3, y: 7)
            case 3:
                self.initPosition = CGPoint(x: 5, y: 7)
            case 4:
                self.initPosition = CGPoint(x: 7, y: 7)
            default:
                self.initPosition = CGPoint(x: 9, y: 7)
            }
        }
        else
        {
            switch no {
            case 1:
                self.initPosition = CGPoint(x: 1, y: 4)
            case 2:
                self.initPosition = CGPoint(x: 3, y: 4)
            case 3:
                self.initPosition = CGPoint(x: 5, y: 4)
            case 4:
                self.initPosition = CGPoint(x: 7, y: 4)
            default:
                self.initPosition = CGPoint(x: 9, y: 4)
            }
        }
        
    }
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        setImg(imgName: "zu.GIF")
        gifName = "gif/bin.gif"

        typeName = "Pawn (Soldier)"
        ruleWords = "The Pawns (Soldiers) move one space at a time. If a pawn does not cross the river yet, it can only move forward vertically. Once crossing the river, the pawn can also move horizontally."
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension UIView {

    func addOnClickListener(target: AnyObject, action: Selector) {
        let gr = UITapGestureRecognizer(target: target, action: action)
        gr.numberOfTapsRequired = 1
        isUserInteractionEnabled = true
        addGestureRecognizer(gr)
    }

}



//import Foundation
//import UIKit
//
//public class chess: UIView
//{
//
//    public var ruleWords:String = String()
//    enum s
//    {   case red
//        case black
//    }
//    public struct position {
//        public var x:CGFloat
//        public var y:CGFloat
//    }
//    var side:s = .red
//    public var initPosition = CGPoint(x: 1, y: 1)
//    var currentPosition = position(x: 1, y: 1)
//    var width:CGFloat = 10
//    var no:Int = 1
//
//    var img = UIImage(named: "shi.GIF")
//
//    public func move() ->CGPoint
//    {
//        let destination = CGPoint(x: currentPosition.x, y: currentPosition.y)
//        return destination
//    }
//    public func move(des:CGPoint)
//    {
//        currentPosition.x=des.x-width/2
//        currentPosition.y=des.y-width/2
//        self.frame = CGRect(origin: CGPoint(x: currentPosition.x, y: currentPosition.y), size: self.frame.size)
//    }
//    public func set(sizeOfTheChess:CGFloat,sideOfTheChess:Int,no:Int)
//    {
//        if sideOfTheChess ==  0
//        {
//            self.side = .red
//        }
//        else
//        {
////            print("side == 1")
//            self.side = .black
////            print(self.side)
//        }
//        self.no = no
//        self.width = sizeOfTheChess
//        self.frame = CGRect(x: 0, y:0, width: width, height: width)
//    }
//    public func setImg(imgName:String)
//    {
//        img = UIImage(named: imgName)
////          self.backgroundColor = UIColor(patternImage: img!)
//        self.layer.contents = img?.cgImage
//
//    }
//    public func setPosition(p:CGPoint)
//    {
//        let position = CGPoint(x: p.x-width/2, y: p.y-width/2)
//        self.frame=CGRect(origin: position, size: self.frame.size)
//    }
//    public override init(frame: CGRect) {
//        super.init(frame: frame)
//
//        self.frame = CGRect(x: 0, y:0, width: width, height: width)
////          self.backgroundColor = .red
////          self.backgroundColor = UIColor(patternImage: img!)
//        self.layer.contents = img?.cgImage
//    }
//    required init?(coder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//}
//
//
//public class che:chess
//{
//
//    public override func move() -> CGPoint {
//        var des = super.move()
//        des.y = currentPosition.y+1
//        if side == .red
//        {
//            des.y = currentPosition.y-1
//        }
//        return des
//    }
//    public override func set(sizeOfTheChess:CGFloat,sideOfTheChess:Int,no:Int)
//    {
//        super.set(sizeOfTheChess: sizeOfTheChess, sideOfTheChess: sideOfTheChess, no: no)
//
//        if side == .red
//        {
////            print("red set")
//            setImg(imgName: "rche.GIF")
//            if no == 1
//            {
//                self.initPosition = position(x: 1, y: 10)
//            }
//            else
//            {
//                self.initPosition = position(x: 9, y: 10)
//            }
//        }
//        else
//        {
//            setImg(imgName: "che.GIF")
//            if no == 1
//            {
//                self.initPosition = position(x: 1, y: 1)
//            }
//            else
//            {
//                self.initPosition = position(x: 9, y: 1)
//            }
//        }
//
//        currentPosition.x=initPosition.x
//        currentPosition.y=initPosition.y
//    }
//
//    public override init(frame: CGRect) {
//        super.init(frame: frame)
//        setImg(imgName: "che.GIF")
//        ruleWords = "The Rooks (Cars) move one or more spaces horizontally or vertically provided that all positions between the original and final positions are empty."
//    }
//
//    required init?(coder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//}
//public class ma:chess
//{
//    public override func move() -> CGPoint {
//        var des = super.move()
//
//        des.x = currentPosition.x+1
//        des.y = currentPosition.y + 2
//        if side == .red
//        {
//            des.x = currentPosition.x-1
//            des.y = currentPosition.y - 2
//        }
//
//        return des
//    }
//    public override func set(sizeOfTheChess:CGFloat,sideOfTheChess:Int,no:Int)
//    {
//        super.set(sizeOfTheChess: sizeOfTheChess, sideOfTheChess: sideOfTheChess, no: no)
//
//        if side == .red
//        {
//            setImg(imgName: "rma.GIF")
//            if no == 1
//            {
//                self.initPosition = position(x: 2, y: 10)
//            }
//            else
//            {
//                self.initPosition = position(x: 8, y: 10)
//            }
//        }
//        else
//        {
//            if no == 1
//            {
//                self.initPosition = position(x: 2, y: 1)
//            }
//            else
//            {
//                self.initPosition = position(x: 8, y: 1)
//            }
//        }
//
//        currentPosition.x=initPosition.x
//        currentPosition.y=initPosition.y    }
//
//    public override init(frame: CGRect) {
//        super.init(frame: frame)
//        setImg(imgName: "ma.GIF")
//        ruleWords = "The Knights (Horses) move two spaces horizontally and one space vertically (or respectively 2 spaces vertically and one space horizontally). If there is a piece next to the horse in the horizontal (vertical) direction, the horse is blocked and the move is not allowed"
//    }
//
//    required init?(coder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//}
//public class xiang:chess
//{
//    public override func move() -> CGPoint {
//        var des = super.move()
//
//        des.x = currentPosition.x + 2
//        des.y = currentPosition.y + 2
//
//        if side == .red
//        {
//            des.x = currentPosition.x - 2
//            des.y = currentPosition.y - 2
//        }
//
//        return des
//    }
//    public override func set(sizeOfTheChess:CGFloat,sideOfTheChess:Int,no:Int)
//    {
//        super.set(sizeOfTheChess: sizeOfTheChess, sideOfTheChess: sideOfTheChess, no: no)
//
//        if side == .red
//        {
//            setImg(imgName: "rxiang.GIF")
//            if no == 1
//            {
//                self.initPosition = position(x: 3, y: 10)
//            }
//            else
//            {
//                self.initPosition = position(x: 7, y: 10)
//            }
//        }
//        else
//        {
//            if no == 1
//            {
//                self.initPosition = position(x: 3, y: 1)
//            }
//            else
//            {
//                self.initPosition = position(x: 7, y: 1)
//            }
//        }
//        currentPosition.x=initPosition.x
//        currentPosition.y=initPosition.y
//    }
//
//    public override init(frame: CGRect) {
//        super.init(frame: frame)
//        setImg(imgName: "xiang.GIF")
//        ruleWords = "The Ministers (Elephants) move two spaces at a time diagonally (i.e. 2 spaces left/right and 2 spaces up/down in a move). They must stay within their own side of the river. If there is a piece midway between the original and final intended position of a minister, the minister is blocked and the move is not allowed."
//    }
//    required init?(coder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//}
//public class shi:chess
//{
//    public override func move() -> CGPoint {
//        var des = super.move()
//
//
//        if side == .red
//        {
//            des.x = currentPosition.x+1
//            des.y = currentPosition.y - 1
//            if no == 2
//            {
//                des.x = currentPosition.x-1
//                des.y = currentPosition.y - 1
//            }
//        }
//        else
//        {
//            des.x = currentPosition.x+1
//            des.y = currentPosition.y + 1
//            if no == 2
//            {
//                des.x = currentPosition.x-1
//                des.y = currentPosition.y + 1
//            }
//        }
//
//        return des
//    }
//    public override func set(sizeOfTheChess:CGFloat,sideOfTheChess:Int,no:Int)
//    {
//        super.set(sizeOfTheChess: sizeOfTheChess, sideOfTheChess: sideOfTheChess, no: no)
//
//        if side == .red
//        {
//            setImg(imgName: "rshi.GIF")
//            if no == 1
//            {
//                self.initPosition = position(x: 4, y: 10)
//            }
//            else
//            {
//                self.initPosition = position(x: 6, y: 10)
//            }
//        }
//        else
//        {
//            if no == 1
//            {
//                self.initPosition = position(x: 4, y: 1)
//            }
//            else
//            {
//                self.initPosition = position(x: 6, y: 1)
//            }
//        }
//        currentPosition.x=initPosition.x
//        currentPosition.y=initPosition.y
//    }
//
//    public override init(frame: CGRect) {
//        super.init(frame: frame)
//        setImg(imgName: "shi.GIF")
//        ruleWords = "The Guards (Advisor) move only one space at a time diagonally. Similar to the King, the guards must stay within the palace."
//    }
//    required init?(coder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//}
//public class jiang:chess
//{
//    public override func move() -> CGPoint {
//        var des = super.move()
//        des.y = currentPosition.y + 1
//
//        if side == .red
//        {
//            des.y = currentPosition.y - 1
//        }
//
//
//        return des
//    }
//    public override func set(sizeOfTheChess:CGFloat,sideOfTheChess:Int,no:Int)
//    {
//        super.set(sizeOfTheChess: sizeOfTheChess, sideOfTheChess: sideOfTheChess, no: no)
//
//        if side == .red
//        {
//            setImg(imgName: "rjiang.GIF")
//
//                self.initPosition = position(x: 5, y: 10)
//        }
//        else
//        {
//                self.initPosition = position(x: 5, y: 1)
//
//        }
//        currentPosition.x=initPosition.x
//        currentPosition.y=initPosition.y
//    }
//
//    public override init(frame: CGRect) {
//        super.init(frame: frame)
//        setImg(imgName: "jiang.GIF")
//        ruleWords = "The King moves only one space at a time, either horizontally or vertically. Further more, the King must always stay within the palace, which is a square marked with an X"
//    }
//    required init?(coder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//}
//public class pao:chess
//{
//    public override func move() -> CGPoint {
//        var des = super.move()
//        des.x = currentPosition.x
//        des.y = 10
//
//        if side == .red
//        {
//            des.y = 1
//        }
//
//        return des
//    }
//    public override func set(sizeOfTheChess:CGFloat,sideOfTheChess:Int,no:Int)
//    {
//        super.set(sizeOfTheChess: sizeOfTheChess, sideOfTheChess: sideOfTheChess, no: no)
//
//        if side == .red
//        {
//            setImg(imgName: "rpao.GIF")
//            if no == 1
//            {
//                self.initPosition = position(x: 2, y: 8)
//            }
//            else
//            {
//                self.initPosition = position(x: 8, y: 8)
//            }
//        }
//        else
//        {
//            if no == 1
//            {
//                self.initPosition = position(x: 2, y: 3)
//            }
//            else
//            {
//                self.initPosition = position(x: 8, y: 3)
//            }
//        }
//
//        currentPosition.x=initPosition.x
//        currentPosition.y=initPosition.y    }
//
//    public override init(frame: CGRect) {
//        super.init(frame: frame)
//        setImg(imgName: "pao.GIF")
//        ruleWords = "The Cannons move one or more spaces horizontally or vertically like a Rook. However, in a capture move, there must be exactly one non-empty space in between the original and final position. In a non-capture move, all spaces in between must be empty."
//    }
//    required init?(coder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//}
//public class zu:chess
//{
//    public override func move() -> CGPoint {
//        var des = super.move()
//        des.x = currentPosition.x
//        des.y = currentPosition.y + 1
//        if side == .red
//        {
//            des.y = currentPosition.y - 1
//        }
//        return des
//    }
//    public override func set(sizeOfTheChess:CGFloat,sideOfTheChess:Int,no:Int)
//    {
//        super.set(sizeOfTheChess: sizeOfTheChess, sideOfTheChess: sideOfTheChess, no: no)
//
//        if side == .red
//        {
//            setImg(imgName: "rzu.GIF")
//            switch no {
//            case 1:
//                self.initPosition = position(x: 1, y: 7)
//            case 2:
//                self.initPosition = position(x: 3, y: 7)
//            case 3:
//                self.initPosition = position(x: 5, y: 7)
//            case 4:
//                self.initPosition = position(x: 7, y: 7)
//            default:
//                self.initPosition = position(x: 9, y: 7)
//            }
//        }
//        else
//        {
//            switch no {
//            case 1:
//                self.initPosition = position(x: 1, y: 4)
//            case 2:
//                self.initPosition = position(x: 3, y: 4)
//            case 3:
//                self.initPosition = position(x: 5, y: 4)
//            case 4:
//                self.initPosition = position(x: 7, y: 4)
//            default:
//                self.initPosition = position(x: 9, y: 4)
//            }
//        }
//        currentPosition.x=initPosition.x
//        currentPosition.y=initPosition.y    }
//
//    public override init(frame: CGRect) {
//        super.init(frame: frame)
//        setImg(imgName: "zu.GIF")
//        ruleWords = "The Pawns (or Soldiers) move one space at a time. If a pawn does not cross the river yet, it can only move forward vertically. Once crossing the river, the pawn can also move horizontally."
//    }
//    required init?(coder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//}
//
//extension UIView {
//
//    func addOnClickListener(target: AnyObject, action: Selector) {
//        let gr = UITapGestureRecognizer(target: target, action: action)
//        gr.numberOfTapsRequired = 1
//        isUserInteractionEnabled = true
//        addGestureRecognizer(gr)
//    }
//
//}
