import Foundation
import UIKit
import SwiftUI


public class chessButtonClass:UIButton
{
    public var no = 0;
    public override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}




public class interBoardView: UIView {
    var screen = CGSize()
    var chessButton:[chessButtonClass] = [chessButtonClass]()
    public var chesses:[chess] = [pao(),che(),ma(),xiang(),shi(),jiang(),pao(),che(),ma(),xiang(),shi(),zu(),zu(),zu(),zu(),zu(),pao(),che(),ma(),xiang(),shi(),jiang(),pao(),che(),ma(),xiang(),shi(),zu(),zu(),zu(),zu(),zu()]
    enum chessName:Int {
        case rp1
        case rc1
        case rm1
        case rx1
        case rs1
        case rj
        case rp2
        case rc2
        case rm2
        case rx2
        case rs2
        case rz1
        case rz2
        case rz3
        case rz4
        case rz5
        case bp1
        case bc1
        case bm1
        case bx1
        case bs1
        case bj
        case bp2
        case brc2
        case bm2
        case bx2
        case bs2
        case bz1
        case bz2
        case bz3
        case bz4
        case bz5
                                                                                                                            
    }
    
    let lineWidth = 1 / UIScreen.main.scale
    let lineAdjustOffset = 1 / UIScreen.main.scale / 2
    var width:CGFloat = 80
    var height:CGFloat = 90
//    var padding:CGFloat = 50
    var colWidth:CGFloat = 10
    var rowHeight:CGFloat = 10
    var l = UILabel()
    
    var chuhe = UIImageView(image: UIImage(named: "楚河.png"))
    var hanjie = UIImageView(image: UIImage(named: "hanjie.png"))

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        l = UILabel.init(frame: CGRect(x: 0, y: self.height+10, width: width, height: 200))

        l.textColor = .black
        l.backgroundColor = .white
        l.text = "   "
        l.backgroundColor = UIColor(patternImage: UIImage(named: "bg.jpeg")!)
        l.alpha = 0.9
//        l.font = UIFont.systemFont(ofSize: 30)
        l.shadowColor = .gray
        l.textAlignment = .center
        l.font = UIFont.boldSystemFont(ofSize: 20)
        l.adjustsFontSizeToFitWidth = true
        l.numberOfLines = 0
        let img = UIImage(named: "bg4.bmp")
        l.backgroundColor = UIColor(patternImage: img!)
        self.addSubview(l)

        let boardBg = UIImage(named: "bg2.bmp")
//        self.layer.contents = boardBg?.cgImage
        self.backgroundColor = UIColor(patternImage: boardBg!)
        
        chuhe.frame = CGRect(origin: getCordinate(x: 2, y: 5), size: CGSize(width: colWidth*2, height: rowHeight))
//        chuhe.backgroundColor = .clear
//        chuhe.textAlignment = .center
//        chuhe.text = "楚河"
//        chuhe.textColor = .black
//        chuhe.font = UIFont.systemFont(ofSize: 30)
//        chuhe.adjustsFontSizeToFitWidth = true
        
        hanjie.frame = CGRect(origin: getCordinate(x: 6, y: 5), size: CGSize(width: colWidth*2, height: rowHeight))
//        hanjie.backgroundColor = .clear
//        hanjie.textAlignment = .center
//        hanjie.text = "汉界"
//        hanjie.textColor = .black
//        hanjie.font = UIFont.systemFont(ofSize: 30)
//        hanjie.adjustsFontSizeToFitWidth = true
        
        self.addSubview(chuhe)
        self.addSubview(hanjie)
        
        for index in 0...31
        {
            self.addSubview(chesses[index])
//            self.addSubview(chessesB[index])

        }
    }
    
    
    public func setSizeAndPosition(width: CGFloat,x:CGFloat,y:CGFloat, screenWidth:CGFloat,screenHeight:CGFloat)
    {
        
        
        self.screen.height = screenHeight
        self.screen.width = screenWidth
        self.width = width
        self.height = width/10.0*11.0
        colWidth = width/10
        rowHeight = height/11
        self.frame = CGRect(x: x, y: y, width: width, height: screenHeight)
//        print(screenHeight)
//        print(height)
        l.frame = CGRect(x: 0, y: self.height+10, width: width, height: screenHeight-height-10)
//        print(l.frame.height)
        chuhe.frame = CGRect(origin: getCordinate(x: 2, y: 5), size: CGSize(width: colWidth*2, height: rowHeight))
        hanjie.frame = CGRect(origin: getCordinate(x: 6, y: 5), size: CGSize(width: colWidth*2, height: rowHeight))
        
        
        
        
        for index in 0...10
        {
            
            chesses[index].set(sizeOfTheChess:colWidth*0.9,sideOfTheChess:0,no:index<6 ? 1 : 2)
            chesses[index].setPosition(p: getCordinate(x: Int(chesses[index].initPosition.x), y: Int(chesses[index].initPosition.y)))

            chesses[index+16].set(sizeOfTheChess:colWidth*0.9,sideOfTheChess:1,no:index<6 ? 1 : 2)
            chesses[index+16].setPosition(p: getCordinate(x: Int(chesses[index+16].initPosition.x), y: Int(chesses[index+16].initPosition.y)))
        }

        for index in 11...15
        {
            chesses[index].set(sizeOfTheChess:colWidth*0.9,sideOfTheChess:0,no:index-10)
            chesses[index].setPosition(p: getCordinate(x: Int(chesses[index].initPosition.x), y: Int(chesses[index].initPosition.y)))


            
            chesses[index+16].set(sizeOfTheChess:colWidth*0.9,sideOfTheChess:1,no:index-10)
            chesses[index+16].setPosition(p: getCordinate(x: Int(chesses[index+16].initPosition.x), y: Int(chesses[index+16].initPosition.y)))
        }
        
        
        for i in 0...31
        {
            chessButton.append(chessButtonClass(frame: chesses[i].frame))
            chessButton[i].backgroundColor = .clear
            chessButton[i].no = i
            self.addSubview(chessButton[i])
            chessButton[i].addTarget(self, action: #selector(chessMove), for: .allEvents)
        }

        
    }
    
    public class showViewClass:UIView
    {
        var button = UIButton()
        var imageView = UIImageView()
        var label1 = UILabel()
        var label2 = UILabel()
        var label3 = UILabel()
        
        public func showGif(gifName:String)
        {
            imageView.frame = CGRect(x: self.frame.width/2-100  , y: label1.frame.maxY+10, width: 200, height: 200)
            self.addSubview(imageView)
            
            // 加载Gif图片, 并且转成Data类型,"my.gif就是gif图片"
            guard let path = Bundle.main.path(forResource: gifName, ofType: nil) else { return }
            guard let data = NSData(contentsOfFile: path) else { return }
            
            // 从data中读取数据: 将data转成CGImageSource对象
            guard let imageSource = CGImageSourceCreateWithData(data, nil) else { return }
            let imageCount = CGImageSourceGetCount(imageSource)
            
            // 便利所有的图片
            var images = [UIImage]()
            var totalDuration : TimeInterval = 0
            for i in 0..<imageCount {
                // .取出图片
                guard let cgImage = CGImageSourceCreateImageAtIndex(imageSource, i, nil) else { continue }
                let image = UIImage(cgImage: cgImage)
                if i == 0 {
                    imageView.image = image
                }
                images.append(image)
                // 取出持续的时间
                guard let properties = CGImageSourceCopyPropertiesAtIndex(imageSource, i, nil) else { continue }
                guard let gifDict = (properties as NSDictionary)[kCGImagePropertyGIFDictionary] as? NSDictionary else { continue }
                guard let frameDuration = gifDict[kCGImagePropertyGIFDelayTime] as? NSNumber else { continue }
                totalDuration += frameDuration.doubleValue
            }
            
            // 设置imageView的属性
            imageView.animationImages = images
            imageView.animationDuration = totalDuration*0.8
            imageView.animationRepeatCount = 0
            
            // 开始播放
            imageView.startAnimating()
        }
        
        
        public func setSize(frame:CGRect,c:chess)
        {
            self.frame = frame
//            print(frame)
            
            label1.frame = CGRect(x:  frame.width*0.05, y: 20, width: frame.width*0.9, height: 40)
            label1.textColor = .black
    //        l.backgroundColor = .lightGray
            label1.text = c.typeName
    //        l.font = UIFont.systemFont(ofSize: 30)
            label1.shadowColor = .gray
            label1.textAlignment = .center
            label1.font = UIFont.boldSystemFont(ofSize: 30)
            label1.adjustsFontSizeToFitWidth = true
            label1.numberOfLines = 0
            self.addSubview(label1)
            
            

            
            label2.frame = CGRect(x:  frame.width*0.05, y: imageView.frame.maxY+20, width: frame.width*0.9, height: 150)
            label2.textColor = .black
    //        l.backgroundColor = .lightGray
            label2.text = c.ruleWords
    //        l.font = UIFont.systemFont(ofSize: 30)
            label2.shadowColor = .gray
            label2.textAlignment = .center
            label2.font = UIFont.boldSystemFont(ofSize: 20)
            label2.adjustsFontSizeToFitWidth = true
            label2.numberOfLines = 0
            self.addSubview(label2)
            
//            label3.frame = CGRect(x:  frame.width*0.05, y: label2.frame.maxY+20, width: frame.width*0.9, height: 50)
//            label3.textColor = .black
//            label3.alpha = 0.7
//    //        l.backgroundColor = .lightGray
//            label3.text = "Tap Return to see more"
//    //        l.font = UIFont.systemFont(ofSize: 30)
//            label3.shadowColor = .gray
//            label3.textAlignment = .center
//            label3.font = UIFont.boldSystemFont(ofSize: 20)
//            label3.adjustsFontSizeToFitWidth = true
//            label3.numberOfLines = 0
//            self.addSubview(label3)
            
            button.frame = CGRect(x: frame.maxX/2-100, y: label2.frame.maxY+20, width: 200, height: 50)
            button.backgroundColor = .white
            self.addSubview(button)
            button.layer.cornerRadius = 10
            button.layer.masksToBounds = true
            button.setTitle("return to see more", for: .normal)//普通状态下文字
            button.setTitle("see more", for: .highlighted)//触摸状态下
            button.setTitleColor(UIColor.black, for: .normal)//普通状态下文字颜色
            button.setTitleColor(UIColor.red, for: .highlighted)//触摸状态下文字的颜色

            button.addTarget(self, action: #selector(buttReturn), for: .allEvents)
            
            
        }
        @objc func buttReturn(_ sender:UIButton) {
            self.alpha = 0.8
            self.removeFromSuperview()
        }
        
        
        public override init(frame: CGRect) {
            super.init(frame: frame)
            self.backgroundColor = .white
            let bg = UIImage(named: "bg4.bmp")
            self.layer.contents = bg?.cgImage
            self.alpha = 0.5
        }

        required init?(coder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
    var showView = showViewClass()
    @objc public func chessMove(_ sender: chessButtonClass){
        
        showView.setSize(frame: CGRect(x: 0, y: 0, width: width, height: self.frame.height), c: chesses[sender.no])
        UIView.animate(withDuration: 1.3, animations: {
            self.showView.alpha = 1
        })
        showView.showGif(gifName: chesses[sender.no].gifName)
        self.addSubview(showView)
        self.frame = CGRect(origin: CGPoint(x: (screen.width-width)/2, y: 0), size: self.frame.size)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public override func draw(_ rect: CGRect) {
        super.draw(rect)


        guard let context = UIGraphicsGetCurrentContext() else
        {
            return
        }

        let drawingRect = self.bounds.insetBy(dx: lineAdjustOffset, dy: lineAdjustOffset)

        //创建并设置路径
       let path = CGMutablePath()
       //外边框
//         path.addRect(drawingRect)
        
        
        for x in 1...9
        {
            path.move(to: getCordinate(x: x, y: 1))
            path.addLine(to: getCordinate(x: x, y: 5))
            
            path.move(to: getCordinate(x: x, y: 6))
            path.addLine(to: getCordinate(x: x, y: 10))

        }
        for y in 1...10
        {
            path.move(to: getCordinate(x: 1, y: y))
            path.addLine(to: getCordinate(x: 9, y: y))
        }
        
        path.move(to: getCordinate(x: 4, y: 1))
        path.addLine(to: getCordinate(x: 6, y: 3))
        
        path.move(to: getCordinate(x: 4, y: 3))
        path.addLine(to: getCordinate(x: 6, y: 1))
        
        path.move(to: getCordinate(x: 4, y: 8))
        path.addLine(to: getCordinate(x: 6, y: 10))
        
        path.move(to: getCordinate(x: 4, y: 10))
        path.addLine(to: getCordinate(x: 6, y: 8))
        

       //添加路径到图形上下文
       context.addPath(path)

       //设置笔触颜色
       context.setStrokeColor(UIColor.black.cgColor)
       //设置笔触宽度
       context.setLineWidth(lineWidth)

       //绘制路径
       context.strokePath()

    }
    public func getCordinate(x:Int, y:Int) -> CGPoint
    {
        var cordinate = CGPoint(x: 0, y: 0)
        cordinate.x = colWidth*CGFloat(x)
        cordinate.y = rowHeight*CGFloat(y)
        return cordinate
    }
    public func getChessPosition(p:CGPoint) ->CGPoint
    {
        var cor = getCordinate(x: Int(p.x), y: Int(p.y))
        cor.x=cor.x-colWidth/2
        cor.y = cor.y-colWidth/2
        return cor
    }
}
