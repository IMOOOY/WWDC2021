import Foundation


import UIKit

public class interIntroView:UIView
{
    public var introBoard = interBoardView()
    var introLabel = UILabel()
    public override init(frame: CGRect) {
        super.init(frame: frame)
        
//        self.backgroundColor = .white
        let bg = UIImage(named: "bg.jpeg")
        self.layer.contents = bg?.cgImage
        introLabel = UILabel.init(frame: CGRect(x: self.frame.width*0.05, y: 0, width: self.frame.width*0.9, height: 110))
        labelInit(l: introLabel)
        self.addSubview(introLabel)
        
        
        
        let width:CGFloat = self.frame.width*0.8
//        introBoard.setSizeAndPosition(width: width,x:(self.frame.width-width)/2,y:introLabel.frame.maxY+10, screenWidth:self.frame.width,screenHeight:self.frame.height)
        introBoard.setSizeAndPosition(width: self.frame.width,x:0,y:introLabel.frame.maxY+10, screenWidth:self.frame.width,screenHeight:self.frame.height)

//        introBoard.setSize(width: width, padding: 0,screenWidth: self.frame.width)
        self.addSubview(introBoard)
        
    }
    
    public func setIntroWords()
    {
        
    }
    
    public func labelInit(l:UILabel )
    {
        l.textColor = .black
//        l.backgroundColor = .lightGray
        l.text = "choose a chess to learn its rule of moving:"
//        l.font = UIFont.systemFont(ofSize: 30)
        l.shadowColor = .white
        l.textAlignment = .center
        l.font = UIFont.boldSystemFont(ofSize: 25)
        l.adjustsFontSizeToFitWidth = true
        l.numberOfLines = 0
        
        
    }
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}



