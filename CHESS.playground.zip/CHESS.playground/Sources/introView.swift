import Foundation
import UIKit

public class introView:UIView
{
    let introBoard = boardView()
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        
//        self.backgroundColor = .white
        let bg = UIImage(named: "bg.jpeg")
        self.layer.contents = bg?.cgImage
        var introLabel = UILabel.init(frame: CGRect(x: self.frame.width*0.05, y: 5, width: self.frame.width*0.9, height: 110))
        labelInit(l: introLabel)
        self.addSubview(introLabel)

        
        
        let width:CGFloat = self.frame.width*0.8
        introBoard.setSizeAndPosition(width: width,x:(self.frame.width-width)/2,y:introLabel.frame.maxY+10, screenWidth:self.frame.width)
//        introBoard.setSize(width: width, padding: 0,screenWidth: self.frame.width)
        self.addSubview(introBoard)
        
        var image1 = UIImageView(image: UIImage(named: "v2-654c1e3dd1cf01d625a1bfedf0b1c70c_1440w.jpg"))
        image1.frame = introBoard.frame
        self.addSubview(image1)
        
        var introLabel2 = UILabel.init(frame: CGRect(x: self.frame.width*0.05, y: introBoard.frame.maxY+10, width: self.frame.width*0.9, height: 200))
        introLabel2.backgroundColor = .white
        introLabel2.alpha = 0.9
        introLabel2.layer.cornerRadius = 10
        introLabel2.clipsToBounds = true
        labelInit(l: introLabel2)
        introLabel2.text = "The board is made up of ten horizontal lines and nine vertical lines. The verticals are interrupted by a central-horizontal void called a river. Two palaces are positioned at opposite sides of the board. Each is distinguished by a cross connecting its four corner points.\n Chess pieces are played on line intersections which are called points. And each has its own rule"
        self.addSubview(introLabel2)
        
        
        
        introLabel.alpha = 0
        introBoard.alpha = 0
        introLabel2.alpha = 0
        image1.alpha = 0
        UIView.animate(withDuration: 2,delay: 1, animations: {() -> Void in
            introLabel.text = "CHNESE CHESS"
            introLabel.font = UIFont.boldSystemFont(ofSize: 30)
            introLabel.alpha = 1
                }){(finished) -> Void in
                    UIView.animate(withDuration: 2,delay: 1, animations: {() -> Void in
                        image1.alpha = 1
                            }){(finished) -> Void in
                        UIView.animate(withDuration: 2,delay: 1, animations: {() -> Void in
                            image1.alpha = 0
                            self.labelInit(l: introLabel)
                            self.introBoard.alpha = 1
                                }){(finished) -> Void in
                                    UIView.animate(withDuration: 2,delay: 1, animations: {() -> Void in
                                        introLabel2.alpha = 1
                                            }){(finished) -> Void in
                                        }
                            }
                }

            
        }

        
        
        
//        UIView.animate(withDuration: 2,delay: 1, animations: {() -> Void in
//            introLabel.alpha = 1
//                }){(finished) -> Void in
//            UIView.animate(withDuration: 2,delay: 1, animations: {() -> Void in
//                self.introBoard.alpha = 1
//                    }){(finished) -> Void in
//                UIView.animate(withDuration: 2,delay: 1, animations: {() -> Void in
//                    introLabel2.alpha = 1
//                        }){(finished) -> Void in
//                    }
//                }
//        }

    }
    
    public func labelInit(l:UILabel )
    {
        l.textColor = .black
//        l.backgroundColor = .lightGray
        l.text = "It's a kind of chess originated in China.\n\nIt looks like this:"
//        l.font = UIFont.systemFont(ofSize: 30)
        l.shadowColor = .gray
        l.textAlignment = .center
        l.font = UIFont.boldSystemFont(ofSize: 20)
        l.adjustsFontSizeToFitWidth = true
        l.numberOfLines = 0
        
        
    }
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
