import UIKit
import PlaygroundSupport
import AVFoundation
import WebKit



var getSize = CGSize(width: UIScreen.main.bounds.size.width , height: UIScreen.main.bounds.size.height - 50)
public class introViewController : UIViewController,AVAudioPlayerDelegate {
    public override func viewDidLoad()
    {
        super.viewDidLoad()
        let basicView = UIView(frame: CGRect(origin: .zero, size: CGSize(width: 400, height: getSize.height)))
        basicView.backgroundColor = .red
        self.view = basicView
        let intro = introView(frame: CGRect(origin: CGPoint(x: 0, y: 0), size: CGSize(width: 400, height: getSize.height)))
        self.view.addSubview(intro)
        let musicStr = Bundle.main.path(forResource: "bgm", ofType: ".mp3")
        playMusic(musicUrl: URL(fileURLWithPath: musicStr!))
    }
}


public class ruleMyViewController : UIViewController,AVAudioPlayerDelegate {
    public override func viewDidLoad()
    {
        super.viewDidLoad()
        let basicView = UIView(frame: CGRect(origin: .zero, size: CGSize(width: 400, height: getSize.height)))
        basicView.backgroundColor = .red
        self.view = basicView
        let intro = interIntroView(frame: CGRect(origin: CGPoint(x: 0, y: 0), size: CGSize(width: 400, height: getSize.height)))
        self.view.addSubview(intro)
        let musicStr = Bundle.main.path(forResource: "bgm", ofType: ".mp3")
        playMusic(musicUrl: URL(fileURLWithPath: musicStr!))
    }
}

public class gameMyViewController : UIViewController,  WKUIDelegate, UIWebViewDelegate {
    public override func viewDidLoad() {
        
        super.viewDidLoad()
        
        var webView = UIWebView()
        webView.delegate = self
//        webView.backgroundColor = #colorLiteral(red: 0.1411764771, green: 0.3960784376, blue: 0.5647059083, alpha: 1)
        view = webView
        guard let url =  Bundle.main.url(forResource: "chess", withExtension: "html" ) else {
            print("not fund")
            return
        }
        let request = URLRequest(url: url)
        webView.loadRequest(request)
        let musicStr = Bundle.main.path(forResource: "bgm", ofType: ".mp3")
        playMusic(musicUrl: URL(fileURLWithPath: musicStr!))
        
        
        
        
    }
}

//public class gameMyViewController: UIViewController, WKUIDelegate {
//
//    var webView: WKWebView!
//
//    override func loadView() {
//        let webConfiguration = WKWebViewConfiguration()
//        webView = WKWebView(frame: .zero, configuration: webConfiguration)
//        webView.uiDelegate = self
//        view = webView
//    }
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
////          guard let fileURL = Bundle.main.url(forResource: "Example2_3表格标签的简单应用", withExtension: "html") else { return  }
//////          webView.loadHTMLString(fileURL!, baseURL: Bundle.main.bundleURL)
////          webView.loadFileURL(fileURL, allowingReadAccessTo: Bundle.main.bundleURL)
//////
////          let myURL = URL(string:"https://www.apple.com")
////          let myRequest = URLRequest(url: myURL!)
////          webView.load(myRequest)
//
//
//        let path = Bundle.main.bundlePath
//        let url = URL.init(fileURLWithPath: path)
//        guard let htmlPath = Bundle.main.path(forResource: "index", ofType: "html") else { return  }
//        let htmlContent = try!String.init(contentsOfFile: htmlPath)
//        webView.loadHTMLString(htmlContent, baseURL: url)
//
//
//    }}
//
